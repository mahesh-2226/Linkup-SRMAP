    module.exports = (err, req, res, next) => {
        err.statusCode = err.statusCode || 500;
        err.status = err.status || "error";

        res.status(err.statusCode).json({
            status: err.status,
            message: err.message,
            // Only include stack trace in development mode for security reasons
            ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
        });
    };