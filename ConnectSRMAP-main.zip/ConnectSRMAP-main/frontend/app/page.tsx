import  Home  from '@/components/Home/home'
import { Button } from '@/components/ui/button'
import React from 'react'
const Homepage = () => {
  return <div>
    <Home/>
  </div>
}

export default Homepage

