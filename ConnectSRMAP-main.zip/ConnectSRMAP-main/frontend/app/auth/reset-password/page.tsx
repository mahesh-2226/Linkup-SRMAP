import ResetPassword from '@/components/Auth/ResetPassword'
import React from 'react'


const ResetPasswordPage = () => {
  return (
    <>
    <ResetPassword/>
    </>
  )
}

export default ResetPasswordPage