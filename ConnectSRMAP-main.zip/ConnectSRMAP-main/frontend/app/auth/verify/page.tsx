import Verify from '@/components/Auth/Verify'
import React from 'react'

const VerifyPage = () => {
  return (<>
    <Verify />
    </>
  );
};

export default VerifyPage