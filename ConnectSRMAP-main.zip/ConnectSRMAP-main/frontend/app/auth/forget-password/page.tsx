import React from 'react'
import ForgetPassword from '@/components/Auth/ForgetPassword'
const Forgetpassword = () => {
  return (<>
  <ForgetPassword />
  </>
  )
}

export default Forgetpassword;