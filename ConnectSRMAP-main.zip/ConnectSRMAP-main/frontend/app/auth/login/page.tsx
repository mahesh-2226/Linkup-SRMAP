import Login from '@/components/Auth/Login'
import React from 'react'

const LoginPage = () => {
  return( <>
    <Login />
  </>
  );
};

export default LoginPage